package Assignment_1;

import java.awt.Point;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.chrome.ChromeDriver;

public class To_Move_Window_Co_Ordinates {
	public static void main(String[] args) throws InterruptedException
	{
	/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	
	//driver.manage().window().maximize();
	driver.get("https://skillrary.com/");
	
	Thread.sleep(3000);
	
	
	driver.manage().window().setPosition(new Point(100,50));*/
}

}