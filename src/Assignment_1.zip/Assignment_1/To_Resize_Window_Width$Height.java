package Assignment_1;

import java.awt.Dimension;

import org.openqa.selenium.chrome.ChromeDriver;

public class To_Resize_Window_Width$Height 
{

public static void main(String[] args)
{
	/*(System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	
	//driver.manage().window().maximize();
	driver.get("https://skillrary.com/");
	
	Thread.sleep(3000);
	
	Dimension dimension = new Dimension(1500,900);
	driver.manage().window().setSize(dimension);*/

	

	

}
}
